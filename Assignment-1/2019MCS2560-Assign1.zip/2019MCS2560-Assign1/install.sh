module load compiler/python/3.6.0/ucs4/gnu/447
git clone https://github.com/ChinmayDegwekar/DataMiningAssignments.git

