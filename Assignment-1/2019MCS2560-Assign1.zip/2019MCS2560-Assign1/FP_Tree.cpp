#include<iostream>
#include<bits/stdc++.h>
#include<fstream>
using namespace std;

class Node
{
	public:
	int itemId;
	float count;
	Node* parent;
	vector<Node*> children;

	Node(int i, float c, Node* p)
	{
		itemId = i;
		count = c;
		parent = p;
	}
};

float minSupport;
int totalTransactions;
unordered_map<int,float> frequency;
unordered_map<int,int> itemOrder;
ofstream output;
unordered_map<int,float>* countMap;

bool sortPairs (pair<int,float> A, pair<int,float> B)
{
	return A.second > B.second;
}

void assignOrder(vector<pair<int,float>> itemFreqs)
{
	int i=0;
	for (auto it=itemFreqs.begin(); it!=itemFreqs.end(); it++)
	{
                itemOrder[it->first] = i;
		i++;
	}
}

bool sortByOrder (int A, int B)
{
	return itemOrder[A] < itemOrder[B];
}

void constructFpTree(vector<int> transaction, Node *fpTree,  unordered_map<int, vector<Node*>>* headerTable)
{
	Node* node = fpTree;
	for (auto item: transaction)
	{
		
		bool found = false;
		for (auto it = node->children.begin(); it != node->children.end(); it++)
		{
			if ((*it)->itemId == item)
			{
				found = true;
				(*it)->count++;
				node = (*it);
				break;
			}
		}

		if (!found)
		{
			Node* newNode = new Node(item, 1, node);
			node->children.push_back(newNode);
			(*headerTable)[item].push_back(newNode);
			node = newNode;
		}
	}
}

bool sortItems(pair<int,float> A, pair<int,float> B)
{
	if ((*countMap)[A.first] > (*countMap)[B.first])
		return true;
	else if ((*countMap)[A.first] == (*countMap)[B.first])
	{
		if (itemOrder[A.first] < itemOrder[B.first])
			return true;
	}
	return false;
}

void constructCondFPTree(vector<pair<int,float>> transaction, Node* condFPTree, unordered_map<int, vector<Node*>>* headTable)
{
	Node* node = condFPTree;
	for (auto i = transaction.begin(); i!=transaction.end(); i++)
    	{

    		bool found = false;
        	for (auto it = node->children.begin(); it != node->children.end(); it++)
        	{
            		if ((*it)->itemId == i->first)
            		{
                		found = true;
                		(*it)->count+= i->second;
                		node = (*it);
                		break;
            		}
        	}

        	if (!found)
        	{
            		Node* newNode = new Node(i->first, i->second, node);
            		node->children.push_back(newNode);
            		(*headTable)[i->first].push_back(newNode);
            		node = newNode;
        	}
    	}
}

void FPGrowth(vector<int> candidateSet, vector<Node*> nodeList)
{
	float count=0;

	for (int i=0; i<nodeList.size(); i++)
		count+=nodeList[i]->count;

	if ((count / totalTransactions) >= minSupport)
	{
		candidateSet.push_back(nodeList[0]->itemId);
		
		int len = candidateSet.size();
                vector<string> cSet(len);
                for(int i = 0; i < len; i++)
                        cSet[i] = to_string(candidateSet[i]);

                sort(cSet.begin(), cSet.end());

                for(int i = 0; i < len; i++)
                        output << cSet[i] << " ";
                output << endl;

		unordered_map<int,float> itemCount;

		for (int i=0; i<nodeList.size(); i++)
		{
			Node* newNode = nodeList[i]->parent;
			while(newNode->itemId!=-1)
			{
				itemCount[newNode->itemId]+=nodeList[i]->count;
				newNode = newNode->parent;
			}
		}

		countMap = &itemCount;

		vector<pair<int,float>> iFreqs(itemCount.begin(), itemCount.end());
		sort(iFreqs.begin(), iFreqs.end(), &sortItems);

		if (iFreqs.size())
		{
			for (auto it=iFreqs.end()-1; it>=iFreqs.begin(); it--)
        		{
            			if ((it->second/totalTransactions) >= minSupport)
                			break;
           			else
           				iFreqs.erase(it);
       	 		}
		}

		Node condFPTree(-1,0,NULL);
		unordered_map<int, vector<Node*>> headTable;

		for (int i=0; i<nodeList.size(); i++)
		{
			vector<pair<int,float>> transaction;
			Node* newNode = nodeList[i]->parent;

			while(newNode->itemId != -1)
			{
				if ((itemCount[newNode->itemId] / totalTransactions) >= minSupport)
				{
					transaction.push_back(make_pair(newNode->itemId, nodeList[i]->count));
				}
				newNode = newNode->parent;
			}

			sort(transaction.begin(), transaction.end(), &sortItems);

			constructCondFPTree(transaction, &condFPTree, &headTable);
		}

		for (int i=iFreqs.size()-1; i>=0; i--)
		{
			FPGrowth(candidateSet, headTable[iFreqs[i].first]);
		}
	}
}

int main(int argc, char* argv[])
{
	if (argc != 4)
	{
		cout << "Enter 3 arguments \n";
		exit(1);		
	}
	
	string inFile, outFile;
	inFile = argv[1];
	outFile = string(argv[3]) + ".txt";
	minSupport = (float)(stoi(argv[2])) / 100;
	
	ifstream input;
	input.open(inFile);

	string line;
	
	while (getline(input,line))
	{
		istringstream ts(line);
		int item;

		while(ts >> item)
			frequency[item]++;

		totalTransactions++;
	}

	input.close();
		
	vector<pair<int,float>> itemFreqs (frequency.begin(), frequency.end());
	sort(itemFreqs.begin(), itemFreqs.end(), &sortPairs);

	for (auto i=itemFreqs.end()-1; i>=itemFreqs.begin(); i--)
	{
		if ((i->second/totalTransactions) >= minSupport)
			break;
		else
			itemFreqs.erase(i);
	}
	
	assignOrder(itemFreqs);

	Node fpTree(-1, 0, NULL);
	unordered_map<int, vector<Node*>> headerTable;
	
	input.open(inFile);	
	while (getline(input,line))
	{
		vector<int> transaction;
		istringstream ts(line);
		int item;
		
		while(ts >> item)
		{
			if (frequency[item] / totalTransactions >= minSupport)
			{
				transaction.push_back(item);
			}
		}

		sort (transaction.begin(), transaction.end(), &sortByOrder);

		constructFpTree(transaction, &fpTree, &headerTable);
	}

	output.open(outFile);
	
	for (int i=itemFreqs.size()-1; i>=0; i--)
	{
		FPGrowth(vector<int>(), headerTable[itemFreqs[i].first]);
	}
	
	output.close();

}


