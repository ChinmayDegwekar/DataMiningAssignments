#include<bits/stdc++.h>
using namespace std;

struct candidate {
    set<int> itemset;
    double frequency;
    int count;
};

bool compare(int a, int b){
	string s1 = to_string(a);
	string s2 = to_string(b);

	return s1 <= s2;
}

bool check_subset(set<int> subset, vector<candidate>& frequent_set){
	for(auto candidate:frequent_set){
		if(candidate.itemset == subset){
			return true;
		}
	}
	return false;
}

bool isPresent(candidate c, vector<candidate> ck) {
    for(int i=0;i<ck.size();i++) {
        if (ck[i].itemset == c.itemset){
            return false;
        }
    }
    return true;
}

void printset(set<int> c){
    for(int a:c){
        cout<<a<<" ";
    }
    cout<<endl;
}

vector<candidate> genCandidate(vector<vector<candidate>>& frequent_sets){
	vector<candidate>& frequent_set = frequent_sets[frequent_sets.size() -1];
	vector<candidate> colln;
	for(int i=0;i<frequent_set.size();i++){
		for(int j=i+1;j<frequent_set.size();j++){
			set<int> temp;
			set_difference(frequent_set[i].itemset.begin(),frequent_set[i].itemset.end(),
				frequent_set[j].itemset.begin(),frequent_set[j].itemset.end(),inserter(temp,temp.end()));

			if(temp.size()==1){
				candidate c;
				c.count = 0;
				c.frequency = 0.0;
				set_union(frequent_set[i].itemset.begin(),frequent_set[i].itemset.end(),
					frequent_set[j].itemset.begin(),frequent_set[j].itemset.end(),inserter(c.itemset,c.itemset.end()));

                bool flag = true;
                for(auto  it=c.itemset.begin();it!=c.itemset.end();it++){
                	set<int> temp = c.itemset;
                    temp.erase(*it);
                    flag = check_subset(temp,frequent_set);
                    if(flag==false){
                    	break;
                    }
                }
             
                if(flag == true) {
                    if (isPresent(c, colln))
                        colln.push_back(c);
                }

			}


		}
	}
	return colln;
}

void apriori(const string in_file, const string out_file, double threshold){
	unordered_map<int,double> C1;

	ifstream inputFile(in_file);

    if (!inputFile) {
        cout << "Error opening file!";
        exit(1); // terminate with error
    }

   	int item;
   	long long int total_transactions=0;
   	string line;

   	while(getline(inputFile,line)){
   		total_transactions++;
   		stringstream stream(line);
   		while(stream>>item){
           if(C1[item] > 0) {
                C1[item] = C1[item] + 1;
            }
            else{
                C1[item] = 1;
            }
   		}

   	}	

   	vector<vector<candidate>> frequent_sets;
   		
   	vector<candidate> F1;
   	for(auto it=C1.begin(); it!=C1.end(); it++){
   		double frequency = it->second * 1.0 / total_transactions;
   		if(frequency >= threshold){
   			candidate c;
            c.itemset.insert(it->first);
            c.count = it->second;
            c.frequency = frequency;
            F1.emplace_back(c);
   		}
   	}

   	frequent_sets.push_back(F1);

   	while(true){
		
		inputFile.clear();
        inputFile.seekg(0, inputFile.beg);
        
        vector<candidate> ck = genCandidate(frequent_sets);
        
        while(getline(inputFile, line)) {
	   		stringstream stream(line);
            set<int> transaction;
            int x;
            while(stream >> x) {
                transaction.insert(x);
            }

            for(auto it=ck.begin();it!=ck.end();it++) {
            	vector<int> diff;
            	set_difference(it->itemset.begin(),it->itemset.end(),transaction.begin(),transaction.end(),back_inserter(diff));
                if(diff.size()==0) {
                    it->count++;
                }
            }
           
        }

        vector<candidate> frequent_set;

        for(int i=0;i<ck.size();i++){
        	ck[i].frequency = (ck[i].count * 1.0) / total_transactions;
        	if(ck[i].frequency >= threshold){
        		frequent_set.push_back(ck[i]);
        	}
        }

        if(frequent_set.size() == 0){
            break;
        }
        else{
            frequent_sets.push_back(frequent_set);
        }
   	}


   	ofstream outputFile(out_file); 
    for(auto &frequent_set : frequent_sets) {
        for(auto &cand : frequent_set) {
        	vector<int> temp(cand.itemset.begin(),cand.itemset.end());
        	sort(temp.begin(),temp.end(),compare);
            for(auto &item : temp) {
                outputFile << item << " ";
            }
            outputFile << "\n";
        }
    }
    outputFile.close();
    inputFile.close();

}