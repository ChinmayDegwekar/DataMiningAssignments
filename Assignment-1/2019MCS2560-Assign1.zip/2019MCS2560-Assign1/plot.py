


from matplotlib import pyplot as plt
import time
import subprocess
import sys
inputfile = sys.argv[1]
inputfile = "test.txt"
thresholds = [1, 5, 10, 25, 50, 90]
#thresholds = [50,60,70,80, 90]
apriori_et = []
fptree_et = []
for x in thresholds:
    start = time.time()
    subprocess.run(["./apriori", str(x),inputfile,"apriori-output-th-"+str(x)+".txt"],shell=True)
    end = time.time()
    apriori_et.append(end-start)
    print( "appriori",x,"ths : ", end-start,"secs")
print(apriori_et)
for x in thresholds:
    start = time.time()
    subprocess.run(["./fptree", str(x),inputfile,"fptree-output-th-"+str(x)+".txt"],shell=True)
    end = time.time()
    fptree_et.append(end-start)
    print( "fptree",x,"ths : ", end-start,"secs")

plt.figure()
plt.plot(thresholds, apriori_et, label='apriori')
plt.plot(thresholds, fptree_et, label='fptree')
plt.title('Execution time comparison')
plt.xlabel('Support threshold')
plt.ylabel('Execution Time (s)')
plt.legend()
plt.show()


# In[ ]:




