g++ main.cpp apriori.cpp -O3 -o apriori -std=c++11
g++ FP_Tree.cpp -O3 -o fptree -std=c++11