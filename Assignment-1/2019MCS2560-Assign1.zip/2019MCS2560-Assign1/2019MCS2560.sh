#./Rollno.sh retail.dat X -apriori output-apriori.txt
#./Rollno.sh retail.dat X -fptree output-fptree.txt
# please note the format
if [ "$3" == "-apriori" ]; then
	./apriori $2 $1 $4
elif [ "$3" == "-fptree" ]; then
 	./fptree $1 $2 $4
elif [ "$2" == "-plot" ]; then
	python3 plot.py $1
else
	echo "Chech the args"
fi