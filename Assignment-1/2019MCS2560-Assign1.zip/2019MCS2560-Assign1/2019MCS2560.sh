#./Rollno.sh retail.dat X -apriori output-apriori.txt
#./Rollno.sh retail.dat X -fptree output-fptree.txt

$DATASET = $1
$SUPPORT = $2
$OUTPUT = $4

if [ "$3" == "-apriori" ]; then
	./apriori $SUPPORT $DATASET $OUTPUT
elif [ "$3" == "-fptree" ]; then
 	./fptree $DATASET $SUPPORT $OUTPUT
elif [ "$2" == "-plot" ]; then
	python3 plot.py $DATASET
else
	echo "Invalid argument"
fi