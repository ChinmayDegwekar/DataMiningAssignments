#include<bits/stdc++.h>
using namespace std;

void apriori(const string infilename, const string outfilename, double threshold);

int main(int argc, char* argv[]){
	if (argc != 4)
	{
		cout << "Enter 3 arguments \n";
		exit(1);		
	}
	/*
	double threshold = 0.2;
	string in_file = "sample_test.txt";
	string out_file = "out.txt";
	*/
	string inFile, outFile;
	inFile = argv[1];
	outFile = string(argv[3]) + ".txt";
	float minSupport = (float)(stoi(argv[2])) / 100;
	
	apriori(inFile, outFile, minSupport);
	
	return 0;
}