Team Members :

- **Sagar Gaddam**		: 2019MCS2570
- **Saswat Pujari**		: 2019MCS2571
- **Chinmay Degwekar**	: 2019MCS2560

Explanation of files

 - 2019MCS2560.sh
	- Command to execute Apriori : 2019MCS2560.sh retail.dat X -apriori output.txt
	- Command to execute FP-Tree : 2019MCS2560.sh retail.dat X -fptree output.txt
	- Command to Plot comparision : 2019MCS2560.sh retail.dat -plot
	
	Where,
		X 			: Support threshold in perentage
	    retail.dat  : Dataset under consideration
		output.txt	: Frequent itemsets, each line corresponding to one itemset(space separated items)
		
 - main.cpp : Driver to run Apriori
 -apriori.cpp : implementation of apriori
 -FP-Tree.cpp : implementation of fp-growth algorithms
 - compile.sh : commands for compilation
 - install.sh : repository clone and python 3.6 module load
 - plot.py : comparative plot on different thresholds

Time Complexity Analysis :
1) DB Scans
	- Apriori : One DB scan per new Candidate
	- FP-Tree : 2 DB scan throughout (assuming FP tree fits in main memory)
2) Overall Time complexity :
	- Apriori : O( n*m^2 ) 
	- FP-tree : O( n )
	where n = total number of transactions
		  m = total number of distinct items
	

Performance comparision of FP and Apriori :
* In Apriori, alrge number of candidates are generated requiring larger memory space
  Whereas FP growth has compact structure and no candidate generation
* FP growth requires only two scans of entire DB compared to multiple scans in apriori
* FP growth algo has smaller execution times by high margin when compared to Apriori
* As we decrease the support threshold, running time of both algorithms increases exponentialy